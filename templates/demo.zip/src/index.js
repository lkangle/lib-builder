const hello = () => {
  console.log('hello lib-builder')
}

hello()
