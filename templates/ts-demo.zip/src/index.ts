const abc = () => {
  console.log('输出abc')
}

abc()
