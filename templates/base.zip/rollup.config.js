import babel from '@rollup/plugin-babel'
import nodeResolve from '@rollup/plugin-node-resolve'
import replace from '@rollup/plugin-replace'
import serve from 'rollup-plugin-serve'
import commonjs from '@rollup/plugin-commonjs'
import { terser } from 'rollup-plugin-terser'
import alias from '@rollup/plugin-alias'
import eslint from '@rollup/plugin-eslint'
import filesize from 'rollup-plugin-filesize'
import { resolve } from 'path'

const extensions = ['.ts', '.js', '.json']
const OUTPUT = 'dist'
const IS_DEV = process.env.NODE_ENV !== 'production'

function getOutput({ file, name, format = 'iife', sourcemap = false }) {
  return {
    file: resolve(OUTPUT, file),
    format,
    sourcemap,
    name
  }
}

function getPlugins(isCdp = false, compress = true) {
  const plugins = [
    commonjs(),
    nodeResolve({
      extensions
    }),
    alias({
      entries: {
        '@': resolve(__dirname, 'src')
      }
    }),
    eslint({
      throwOnError: true
    }),
    babel({
      exclude: 'node_modules',
      babelHelpers: 'bundled',
      extensions
    }),
    replace({
      __IS_CDP__: isCdp
    }),
    filesize({
      showGzippedSize: false
    })
  ]
  if (IS_DEV) {
    plugins.push(serve({
      contentBase: [OUTPUT, 'test'],
      port: 20040
    }))
  } else if (compress) {
    plugins.push(terser({
      mangle: {
        reserved: ['$']
      },
      ie8: true
    }))
  }
  return plugins
}

const config = {
  input: 'src/index.ts',
  output: getOutput({
    file: IS_DEV ? 'index.dev.js' : 'index.js',
    sourcemap: IS_DEV
  }),
  plugins: getPlugins()
}

export default config
